package com.example.e_postoffice;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import org.json.JSONObject;

public class Register extends AppCompatActivity implements JsonResponse {

    String fname,lname,place,phone,email,username,passwrd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE); //will hide the title
        getSupportActionBar().hide(); // hide the title bar
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN); //enable full sc
        setContentView(R.layout.activity_register);

        Button b1 = findViewById(R.id.button2);

        EditText e1 = findViewById(R.id.editTextTextPersonName7);
        EditText e2 = findViewById(R.id.editTextTextPersonName6);
        EditText e3 = findViewById(R.id.editTextTextPersonName2);
        EditText e4 = findViewById(R.id.editTextTextPersonName);
        EditText e5 = findViewById(R.id.username);
        EditText e6 = findViewById(R.id.editTextTextPersonName3);
        EditText e7 = findViewById(R.id.editTextTextPersonName5);

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                fname = e1.getText().toString();
                lname = e2.getText().toString();
                place = e3.getText().toString();
                phone = e4.getText().toString();
                username = e5.getText().toString();
                passwrd= e6.getText().toString();
                email= e7.getText().toString();

                if (fname.equalsIgnoreCase("")) {
                    e1.setError("Enter Your FirstName");
                    e1.setFocusable(true);
                } else if (phone.equalsIgnoreCase("") || phone.length()!=10) {
                    e4.setError("Enter Your Phonenumber");
                    e4.setFocusable(true);
                }
                else if (!email.matches("[a-zA-Z0-9._-]+@[a-z]+\\.[a-z]+")) {
                    e7.setError("Enter Your Valid EmailId");
                    e7.setFocusable(true);
                }
                else if (username.equalsIgnoreCase("")) {
                    e5.setError("Enter Your Username");
                    e5.setFocusable(true);
                }
                else if (lname.equalsIgnoreCase("")) {
                    e2.setError("Enter Your Lastname");
                    e2.setFocusable(true);
                }
                else if (place.equalsIgnoreCase("")) {
                    e3.setError("Enter Your Place");
                    e3.setFocusable(true);
                }
                else if (passwrd.equalsIgnoreCase("")) {
                    e6.setError("Enter Your Password");
                    e6.setFocusable(true);
                }else {

                    JsonReq JR = new JsonReq();
                    JR.json_response = (JsonResponse) Register.this;
                    String q = "/userreg?fname=" + fname +"&lname="+lname+ "&phone=" + phone+ "&email=" + email+ "&uname=" + username+ "&pass=" + passwrd+"&place="+place;
                    q = q.replace(" ", "%20");
                    JR.execute(q);
                }
            }
        });

    }

    @Override
    public void response(JSONObject jo) {
        try {
            String status = jo.getString("status");
            Log.d("pearl", status);

            if (status.equalsIgnoreCase("success")) {

                Toast.makeText(getApplicationContext(), "Registration Successful", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(getApplicationContext(), Login.class));

            }
        }
        catch (Exception e) {
            // TODO: handle exception

            Toast.makeText(getApplicationContext(), e.toString(), Toast.LENGTH_SHORT).show();
        }
    }

    public void onBackPressed()
    {
        // TODO Auto-generated method stub
        super.onBackPressed();
        Intent b=new Intent(getApplicationContext(),Login.class);
        startActivity(b);
    }
}