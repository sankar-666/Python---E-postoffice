package com.example.e_postoffice;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONObject;

public class UserTransferMoney extends AppCompatActivity implements JsonResponse {

    EditText e1,e2;
    Button b1;
    TextView t1,t2;
    SharedPreferences sh;
    String amount,acno;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE); //will hide the title
        getSupportActionBar().hide(); // hide the title bar
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN); //enable full sc
        setContentView(R.layout.activity_user_transfer_money);

        sh= PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        e1=(EditText) findViewById(R.id.tonum);
        e2=(EditText) findViewById(R.id.tomoney);
        b1=(Button) findViewById(R.id.add);

        TextView t1 =findViewById(R.id.textView11);
        TextView t2 =findViewById(R.id.balance);
        t1.setText("Account No : "+UserAccountDetails.acc);
        t2.setText("Balance : "+UserAccountDetails.blnce);

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                acno=e1.getText().toString();
                amount=e2.getText().toString();

                if (acno.equalsIgnoreCase("") || acno.length()!=16) {
                    e1.setError("Enter 16 digit Account Number");
                    e1.setFocusable(true);
                } else if (amount.equalsIgnoreCase("")){
                    e2.setError("Enter Amount to transfer");
                    e2.setFocusable(true);
                }else {

                    if(Integer.parseInt(UserAccountDetails.blnce) < Integer.parseInt(amount) ) {

                        Toast.makeText(getApplicationContext(), "insufficient Balance! ", Toast.LENGTH_SHORT).show();
                    }else {
                         JsonReq JR = new JsonReq();
                        JR.json_response = (JsonResponse) UserTransferMoney.this;
                        String q = "/transfermoney?acno=" + acno + "&amount=" + amount + "&lid=" + sh.getString("log_id", "")+"&myac="+UserAccountDetails.acc;
                        q = q.replace(" ", "%20");
                        JR.execute(q);
                    }

                }
            }
        });
    }

    @Override
    public void response(JSONObject jo) {
        try {
            String status = jo.getString("status");
            Log.d("pearl", status);

            if (status.equalsIgnoreCase("success")) {

                Toast.makeText(getApplicationContext(), "Amount transferred Successfully! ", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(getApplicationContext(), UserAccountDetails.class));

            }else  if (status.equalsIgnoreCase("notfound")) {

                Toast.makeText(getApplicationContext(), "No Valid Account with this account number!!!", Toast.LENGTH_SHORT).show();
//                startActivity(new Intent(getApplicationContext(), UserTransferMoney.class));

            }
        }
        catch (Exception e) {
            // TODO: handle exception

            Toast.makeText(getApplicationContext(), e.toString(), Toast.LENGTH_SHORT).show();
        }
    }
}