package com.example.e_postoffice;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

public class UserViewLetters extends AppCompatActivity implements JsonResponse {

    ListView l1;
    SharedPreferences sh;
    String search;
    String[] letter,t_no,lid,weight,rate,value,fname,lname,place,phone,email;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE); //will hide the title
        getSupportActionBar().hide(); // hide the title bar
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN); //enable full sc
        setContentView(R.layout.activity_user_view_letters);

        sh= PreferenceManager.getDefaultSharedPreferences(getApplicationContext());

        EditText e1=findViewById(R.id.editTextTextPersonName15);
        ImageButton b1 =findViewById(R.id.imageButton2);
        l1=findViewById(R.id.lvletters);



        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                search=e1.getText().toString();

                JsonReq JR = new JsonReq();
                JR.json_response = (JsonResponse) UserViewLetters.this;
                String q = "/viewletters?lid="+sh.getString("log_id","")+"&search="+search;
                q = q.replace(" ", "%20");
                JR.execute(q);
            }
        });





    }

    @Override
    public void response(JSONObject jo) {
        try {

            String method = jo.getString("method");
            Log.d("pearl", method);

            if (method.equalsIgnoreCase("viewletters")) {
                String status = jo.getString("status");
                if (status.equalsIgnoreCase("success")) {
//                    Toast.makeText(getApplicationContext(), "test", Toast.LENGTH_LONG).show();

                    JSONArray ja1 = (JSONArray) jo.getJSONArray("data");
                    letter = new String[ja1.length()];
                    weight= new String[ja1.length()];
                    rate= new String[ja1.length()];
                    t_no= new String[ja1.length()];
                    lid = new String[ja1.length()];
                    value = new String[ja1.length()];
                    fname = new String[ja1.length()];
                    lname= new String[ja1.length()];
                    email= new String[ja1.length()];
                    phone= new String[ja1.length()];
                    place= new String[ja1.length()];


                    for (int i = 0; i < ja1.length(); i++) {
                        letter[i] = ja1.getJSONObject(i).getString("letter");
                        rate[i] = ja1.getJSONObject(i).getString("rate");
                        weight[i] = ja1.getJSONObject(i).getString("weight");
                        t_no[i] = ja1.getJSONObject(i).getString("t_num");
                        lid[i] = ja1.getJSONObject(i).getString("letter_id");

                        fname[i] = ja1.getJSONObject(i).getString("fname");
                        lname[i] = ja1.getJSONObject(i).getString("lname");
                        place[i] = ja1.getJSONObject(i).getString("place");
                        phone[i] = ja1.getJSONObject(i).getString("phone");
                        email[i] = ja1.getJSONObject(i).getString("email");

//                        Toast.makeText(getApplicationContext(), name[i]+" "+num[i], Toast.LENGTH_LONG).show();


                        value[i] = "Letter : " + letter[i] + "\nWeight : " + weight[i] + "\nRate : " + rate[i]+"\nTransaction ID : " + t_no[i] + "\nStation Master : " + fname[i]+lname[i]+"\nPlace : " + place[i] + "\nNumber : " + phone[i]+"\nEmail : " + email[i]+"\n";
                    }
                    ArrayAdapter<String> ar = new ArrayAdapter<String>(getApplicationContext(), android.R.layout.simple_list_item_1, value);
                    l1.setAdapter(ar);

//                    CustomUser a = new CustomUser(this, name, num);
//                    l1.setAdapter(a);
                } else  if (status.equalsIgnoreCase("failed")) {
                    Toast.makeText(getApplicationContext(), "No Letters with this Transaction ID, found!", Toast.LENGTH_SHORT).show();
                }
            }

        }
        catch (Exception e) {
            // TODO: handle exception
            e.printStackTrace();
            Toast.makeText(getApplicationContext(), e.toString(), Toast.LENGTH_SHORT).show();
        }
    }
    public void onBackPressed()
    {
        // TODO Auto-generated method stub
        super.onBackPressed();
        Intent b=new Intent(getApplicationContext(),UserHome.class);
        startActivity(b);
    }
}