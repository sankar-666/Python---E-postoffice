package com.example.e_postoffice;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

public class UserViewProfile extends AppCompatActivity implements JsonResponse {

    String fname,lname,place,phone,email,username,uid;
    SharedPreferences sh;
    EditText e1,e2,e3,e4,e5,e7;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE); //will hide the title
        getSupportActionBar().hide(); // hide the title bar
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN); //enable full sc
        setContentView(R.layout.activity_user_view_profile);

        sh= PreferenceManager.getDefaultSharedPreferences(getApplicationContext());

        Button b1 = findViewById(R.id.button4);

         e1 = findViewById(R.id.editTextTextPersonName9);
         e2 = findViewById(R.id.editTextTextPersonName10);
         e3 = findViewById(R.id.editTextTextPersonName11);
         e4 = findViewById(R.id.editTextTextPersonName12);
         e5 = findViewById(R.id.editTextTextPersonName14);

         e7 = findViewById(R.id.editTextTextPersonName13);

        JsonReq JR = new JsonReq();
        JR.json_response = (JsonResponse) UserViewProfile.this;
        String q = "/userviewprofile?lid=" + sh.getString("log_id","") ;
        q = q.replace(" ", "%20");
        JR.execute(q);

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                fname = e1.getText().toString();
                lname = e2.getText().toString();
                place = e3.getText().toString();
                phone = e4.getText().toString();
                username = e5.getText().toString();

                email= e7.getText().toString();

                if (fname.equalsIgnoreCase("")) {
                    e1.setError("Enter Your FirstName");
                    e1.setFocusable(true);
                } else if (phone.equalsIgnoreCase("") || phone.length()!=10) {
                    e4.setError("Enter Your Phonenumber");
                    e4.setFocusable(true);
                }
                else if (!email.matches("[a-zA-Z0-9._-]+@[a-z]+\\.[a-z]+")) {
                    e7.setError("Enter Your Valid EmailId");
                    e7.setFocusable(true);
                }
                else if (username.equalsIgnoreCase("")) {
                    e5.setError("Enter Your Username");
                    e5.setFocusable(true);
                }
                else if (lname.equalsIgnoreCase("")) {
                    e2.setError("Enter Your Lastname");
                    e2.setFocusable(true);
                }
                else if (place.equalsIgnoreCase("")) {
                    e3.setError("Enter Your Place");
                    e3.setFocusable(true);
                }
               else {

                    JsonReq JR = new JsonReq();
                    JR.json_response = (JsonResponse) UserViewProfile.this;
                    String q = "/userupdateprofile?fname=" + fname +"&lname="+lname+ "&phone=" + phone+ "&email=" + email+ "&uname=" + username+"&place="+place+"&lid=" + sh.getString("log_id","");
                    q = q.replace(" ", "%20");
                    JR.execute(q);
                }
            }
        });
    }

    @Override
    public void response(JSONObject jo) {
        try {

            String method = jo.getString("method");
            Log.d("pearl", method);

            if (method.equalsIgnoreCase("userviewprofile")) {
                String status = jo.getString("status");
                if (status.equalsIgnoreCase("success")) {
//                    Toast.makeText(getApplicationContext(), "test", Toast.LENGTH_LONG).show();

                    JSONArray ja1 = (JSONArray) jo.getJSONArray("data");


                    e1.setText(ja1.getJSONObject(0).getString("fname"));
                    e2.setText(ja1.getJSONObject(0).getString("lname"));
                    e3.setText(ja1.getJSONObject(0).getString("place"));
                    e4.setText(ja1.getJSONObject(0).getString("phone"));
                    e5.setText(ja1.getJSONObject(0).getString("username"));
                    e7.setText(ja1.getJSONObject(0).getString("email"));




                } else  if (status.equalsIgnoreCase("failed")) {
                    Toast.makeText(getApplicationContext(), "Something went Wrong!", Toast.LENGTH_SHORT).show();
                }
            }

            if (method.equalsIgnoreCase("userupdateprofile")) {

                String status = jo.getString("status");
                if (status.equalsIgnoreCase("success")) {
                    Toast.makeText(getApplicationContext(), "Profile Updated Successfully!", Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(getApplicationContext(),UserHome.class));
                }

            }

        }
        catch (Exception e) {
            // TODO: handle exception
            e.printStackTrace();
            Toast.makeText(getApplicationContext(), e.toString(), Toast.LENGTH_SHORT).show();
        }
    }
}