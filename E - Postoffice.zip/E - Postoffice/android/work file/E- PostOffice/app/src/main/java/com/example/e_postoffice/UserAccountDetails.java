package com.example.e_postoffice;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

public class UserAccountDetails extends AppCompatActivity implements JsonResponse, AdapterView.OnItemClickListener {

    ListView l1;
    String[] value,account,sts,balance,account_id;
    public static String blnce,acc,aid;
    SharedPreferences sh;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE); //will hide the title
        getSupportActionBar().hide(); // hide the title bar
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN); //enable full sc
        setContentView(R.layout.activity_user_account_details);

        sh= PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        l1=findViewById(R.id.fd);

        l1.setOnItemClickListener(this);


        JsonReq JR = new JsonReq();
        JR.json_response = (JsonResponse) UserAccountDetails.this;
        String q = "/viewmyaccountlist?lid="+sh.getString("log_id","");
        q = q.replace(" ", "%20");
        JR.execute(q);
    }

    @Override
    public void response(JSONObject jo) {
        try {

            String method = jo.getString("method");
            Log.d("pearl", method);

            if (method.equalsIgnoreCase("viewmyaccountlist")) {
                String status = jo.getString("status");
                if (status.equalsIgnoreCase("success")) {
//                    Toast.makeText(getApplicationContext(), "test", Toast.LENGTH_LONG).show();

                    JSONArray ja1 = (JSONArray) jo.getJSONArray("data");
                    account = new String[ja1.length()];

                    sts= new String[ja1.length()];
                    balance= new String[ja1.length()];
                    account_id= new String[ja1.length()];

                    value = new String[ja1.length()];


                    for (int i = 0; i < ja1.length(); i++) {
                        account[i] = ja1.getJSONObject(i).getString("account");

                        sts[i] = ja1.getJSONObject(i).getString("status");
                        balance[i] = ja1.getJSONObject(i).getString("balance");
                        account_id[i] = ja1.getJSONObject(i).getString("account_id");

//                        Toast.makeText(getApplicationContext(), name[i]+" "+num[i], Toast.LENGTH_LONG).show();


                        value[i] = "Account no : " + account[i] +"\nBalance : "+balance[i];
                    }
                    ArrayAdapter<String> ar = new ArrayAdapter<String>(getApplicationContext(), android.R.layout.simple_list_item_1, value);
                    l1.setAdapter(ar);

//                    CustomUser a = new CustomUser(this, name, num);
//                    l1.setAdapter(a);
                } else  if (status.equalsIgnoreCase("failed")) {
                    Toast.makeText(getApplicationContext(), "No approved accounts, found!", Toast.LENGTH_SHORT).show();
                }
            }

        }
        catch (Exception e) {
            // TODO: handle exception
            e.printStackTrace();
            Toast.makeText(getApplicationContext(), e.toString(), Toast.LENGTH_SHORT).show();
        }
    }


    @Override
    public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

        blnce=balance[i];
        acc=account[i];
        aid=account_id[i];
        final CharSequence[] items = {"Add Amount","Transfer Amount", "Cancel"};

        AlertDialog.Builder builder = new AlertDialog.Builder(UserAccountDetails.this , R.style.CustomDialogTheme);
        TextView textView = new TextView(getApplicationContext());
        textView.setText("Select an option");
        textView.setPadding(20, 30, 20, 30);
        textView.setTextSize(20F);
        textView.setBackgroundColor(Color.parseColor("#F46335"));
        textView.setTextColor(Color.parseColor("#e3e3e3"));
        textView.setGravity(Gravity.CENTER);
        builder.setCustomTitle(textView);
        // builder.setTitle("Add Photo!");
        builder.setItems(items, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int item) {

                if (items[item].equals("Add Amount")) {

                    startActivity(new Intent(getApplicationContext(), UserAddAccountBalance.class));

                }
                else if (items[item].equals("Transfer Amount")) {

                    startActivity(new Intent(getApplicationContext(), UserTransferMoney.class));
                }
                else if (items[item].equals("Cancel")) {
                    dialog.dismiss();
                }

            }

        });
        builder.show();
    }
    public void onBackPressed()
    {
        // TODO Auto-generated method stub
        super.onBackPressed();
        Intent b=new Intent(getApplicationContext(),UserSettings.class);
        startActivity(b);
    }
}