package com.example.e_postoffice;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import org.json.JSONObject;

public class UserRequestFD extends AppCompatActivity implements JsonResponse {

    SharedPreferences sh;
    String amount;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE); //will hide the title
        getSupportActionBar().hide(); // hide the title bar
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN); //enable full sc
        setContentView(R.layout.activity_user_request_fd);
        sh= PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        Button b1 = findViewById(R.id.button);
        EditText e1 = findViewById(R.id.editTextTextPersonName8);

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                amount=e1.getText().toString();

                if (amount.equalsIgnoreCase("")) {
                    e1.setError("Enter Amount to Continue");
                    e1.setFocusable(true);
                }  else {

                    JsonReq JR = new JsonReq();
                    JR.json_response = (JsonResponse) UserRequestFD.this;
                    String q = "/userreqfd?amount="+amount+"&lid="+sh.getString("log_id","")+"&sid="+UserViewStationMaster.st_id;
                    q = q.replace(" ", "%20");
                    JR.execute(q);
                }
            }
        });


    }

    @Override
    public void response(JSONObject jo) {
        try {
            String status = jo.getString("status");
            Log.d("pearl", status);

            if (status.equalsIgnoreCase("success")) {

                Toast.makeText(getApplicationContext(), "FD requested successfully", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(getApplicationContext(), UserHome.class));

            }
        }
        catch (Exception e) {
            // TODO: handle exception

            Toast.makeText(getApplicationContext(), e.toString(), Toast.LENGTH_SHORT).show();
        }
    }
}