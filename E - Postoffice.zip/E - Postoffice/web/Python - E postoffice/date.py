import datetime

# Get the current date
today = datetime.date.today()

# Get the current month and year

def getdate():
    data={}
    month = today.month
    year = today.year
    data['month']=month
    data['year']=year
    return data
