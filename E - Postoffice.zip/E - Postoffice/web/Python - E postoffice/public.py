from flask import *
from database import *


public=Blueprint('public',__name__)

@public.route('/')
def home():
    return render_template('index.html')

@public.route('/login',methods=['post','get'])
def login():

    if 'btn' in request.form:
        uname=request.form['uname']
        pasw =request.form['pasw']

        q="select * from login where username='%s' and password='%s'"%(uname,pasw)
        res=select(q)


        if res:
            session['loginid']=res[0]["login_id"]
            utype=res[0]["usertype"]
            if utype == "admin":
                return redirect(url_for("admin.adminhome"))
            elif utype == "stationmaster":
                q="select * from stationmaster where login_id='%s'"%(session['loginid'])
                val=select(q)
                if val:
                    session['stid']=val[0]['smaster_id']
                    return redirect(url_for("stationmaster.stationmasterhome"))
               
            
            else:
                flash("failed try again")
                return redirect(url_for("public.login"))


    return render_template("login.html")