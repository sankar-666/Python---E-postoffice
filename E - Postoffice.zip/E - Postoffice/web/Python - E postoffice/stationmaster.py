from flask import *
from database import *


stationmaster=Blueprint('stationmaster',__name__)

@stationmaster.route('/stationmasterhome')
def stationmasterhome():
    return render_template('stationmasterhome.html')



@stationmaster.route('/stationmastermanagepostman',methods=['get','post'])
def stationmastermanagepostman():
    data={}

    if 'add' in request.form:
        fname=request.form['fname']
        lname=request.form['lname']
        place=request.form['place']
        num=request.form['num']
        email=request.form['email']
        uname=request.form['uname']
        pasw=request.form['pasw']

        q="insert into login values(null,'%s','%s','postman')"%(uname,pasw)
        lid=insert(q)
        q="insert into postman values(null,'%s','%s','%s','%s','%s','%s') "%(lid,fname,lname,place,num,email)
        insert(q)
        return redirect(url_for("stationmaster.stationmastermanagepostman"))

    q="select * from postman"
    data['res']=select(q)

    if 'action' in request.args:
        action=request.args['action']
        pmid=request.args['pmid']
        logid=request.args['logid']
    else:
        action=None

    if action == "update":
        q="select * from postman where postman_id='%s'"%(pmid)
        data['changeval']=select(q)

        if 'update' in request.form:
            fname=request.form['fname']
            lname=request.form['lname']
            place=request.form['place']
            num=request.form['num']
            email=request.form['email']
          

            q="update postman set fname='%s', lname='%s', place='%s', phone='%s', email='%s' where postman_id='%s' "%(fname,lname,place,num,email,pmid)
            update(q)
            return redirect(url_for("stationmaster.stationmastermanagepostman"))

    if action=='delete':
        q="delete from postman where postman_id='%s'"%(pmid)
        delete(q)
        q="delete from login where login_id='%s'"%(logid)
        delete(q)
        return redirect(url_for("stationmaster.stationmastermanagepostman"))
    return render_template('stationmastermanagepostman.html',data=data)



@stationmaster.route('/stationmastermanageletter',methods=['get','post'])
def stationmastermanageletter():
    data={}

    if 'add' in request.form:
        letter=request.form['letter']
        weight=request.form['weight']
        rate=request.form['rate']
        t_no=request.form['t_no']
        smid=session['stid']
        
        q="insert into letter values(null,'%s','%s','%s','%s','%s') "%(smid,letter,weight,rate,t_no)
        letid=insert(q)
        q="insert into track values(null,'%s','%s',(select place from stationmaster where smaster_id='%s'),'%s','dispatched') "%(letid,smid,smid,t_no)
        print(q)
        insert(q)
        return redirect(url_for("stationmaster.stationmastermanageletter"))

    q="select * from letter"
    data['res']=select(q)

    if 'action' in request.args:
        action=request.args['action']
        lid=request.args['lid']
      
    else:
        action=None

    if action == "update":
        q="select * from letter where letter_id='%s'"%(lid)
        data['changeval']=select(q)

        if 'update' in request.form:
            letter=request.form['letter']
            weight=request.form['weight']
            rate=request.form['rate']
            t_no=request.form['t_no']
          

            q="update letter set letter='%s', weight='%s', rate='%s', t_num='%s' where letter_id='%s' "%(letter,weight,rate,t_no,lid)
            update(q)
            return redirect(url_for("stationmaster.stationmastermanageletter"))

    if action=='delete':
        q="delete from letter where letter_id='%s'"%(lid)
        delete(q)
        return redirect(url_for("stationmaster.stationmastermanageletter"))

    if action == 'track':
        q="select * from track inner join letter using (letter_id) where letter_id='%s' ORDER BY track_id DESC LIMIT 1"%(lid)
        print(q)
        data['trackLocation']=select(q)
        data['testcontent']="hello"
    return render_template('stationmastermanageletter.html',data=data)



@stationmaster.route('/stationmastermanageloan',methods=['get','post'])
def stationmastermanageloan():
    data={}

    if 'add' in request.form:
        loan=request.form['loan']
        details=request.form['details']
        amount=request.form['amount']
        monthlypayable=request.form['monthlypayable']
        smid=session['stid']
        
        q="insert into loan values(null,'%s','%s','%s','%s') "%(loan,details,amount,monthlypayable)
        insert(q)
      
        return redirect(url_for("stationmaster.stationmastermanageloan"))

    q="select * from loan"
    data['res']=select(q)

    if 'action' in request.args:
        action=request.args['action']
        loanid=request.args['loanid']
      
    else:
        action=None

    if action == "update":
        q="select * from loan where loan_id='%s'"%(loanid)
        data['changeval']=select(q)

        if 'update' in request.form:
            loan=request.form['loan']
            details=request.form['details']
            amount=request.form['amount']
            monthlypayable=request.form['monthlypayable']
          

            q="update loan set loan='%s', amount='%s', details='%s', monthlypayable='%s' where loan_id='%s' "%(loan,amount,details,monthlypayable,loanid)
            update(q)
            return redirect(url_for("stationmaster.stationmastermanageloan"))

    if action=='delete':
        q="delete from loan where loan_id='%s'"%(loanid)
        delete(q)
        return redirect(url_for("stationmaster.stationmastermanageloan"))

   
    return render_template('stationmastermanageloan.html',data=data)





@stationmaster.route("/stationmasterviewaccountreq",methods=['get','post'])
def stationmasterviewaccountreq():
    data={}
    smid=session['stid']
    q="select * from account inner join user using (user_id) where smaster_id='%s'"%(smid)
    data['res']=select(q)

    if 'action' in request.args:
        action=request.args['action']
        acid=request.args['acid']
    else:
        action=None
    
    import random

    def get_random_number():
        return str(random.randint(1000000000000000, 9999999999999999))

      
  

    if action == "accept":
        randomnum=get_random_number() 
        print(randomnum)
        q="update account set status='approved' , account='%s' where account_id='%s'"%(randomnum,acid)
        update(q)
        return redirect(url_for("stationmaster.stationmasterviewaccountreq"))
    if action == "reject":
        q="update account set status='rejected' where account_id='%s'"%(acid)
        update(q)
        return redirect(url_for("stationmaster.stationmasterviewaccountreq"))
    return render_template("stationmasterviewaccountreq.html",data=data)

@stationmaster.route("/stationmasteracceptfd",methods=['get','post'])
def stationmasteracceptfd():
    data={}
    smid=session['stid']
    q="select * from fixeddeposit inner join user using (user_id) where smaster_id='%s'"%(smid)
    data['res']=select(q)

    if 'action' in request.args:
        action=request.args['action']
        did=request.args['did']
    else:
        action=None

    if action == "accept":
        q="update fixeddeposit set status='accepted'where deposit_id='%s'"%(did)
        update(q)
        return redirect(url_for("stationmaster.stationmasteracceptfd"))
    if action == "reject":
        q="update fixeddeposit set status='rejected' where deposit_id='%s'"%(did)
        update(q)
        return redirect(url_for("stationmaster.stationmasteracceptfd"))
    return render_template("stationmasteracceptfd.html",data=data)




@stationmaster.route("/stationmasterviewpaymant")
def stationmasterviewpaymant():
    data={}
    loan_id=request.args['loanid']
    reqid=request.args['reqid']
    uid=request.args['uid']
    q="SELECT * FROM `payment` INNER  JOIN `loan` USING (loan_id) INNER JOIN `loanrequest` USING (loan_id) INNER JOIN `user` USING (user_id) where loan_id='%s' and request_id='%s' and user_id='%s'"%(loan_id,reqid,uid)
    res=select(q)
    data['res']=res

    return render_template("stationmasterviewpaymant.html",data=data)

@stationmaster.route("/stationmasteracceptLOANreq")
def stationmasteracceptLOANreq():
    data={}
    
    q="SELECT * FROM  `loan`  INNER JOIN `loanrequest` USING (loan_id) INNER JOIN `user` USING (user_id)"
    res=select(q)
    data['res']=res

    
    if 'action' in request.args:
        action=request.args['action']
        rid=request.args['rid']
    else:
        action=None

    if action == "accept":
        q="update loanrequest set status='accepted'where request_id='%s'"%(rid)
        update(q)
        return redirect(url_for("stationmaster.stationmasteracceptLOANreq"))
    if action == "reject":
        q="update loanrequest set status='rejected' where request_id='%s'"%(rid)
        update(q)
        return redirect(url_for("stationmaster.stationmasteracceptLOANreq"))
    return render_template("stationmasteracceptLOANreq.html",data=data)   