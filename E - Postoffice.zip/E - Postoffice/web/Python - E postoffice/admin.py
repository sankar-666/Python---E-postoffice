from flask import *
from database import *


admin=Blueprint('admin',__name__)

@admin.route('/adminhome')
def adminhome():
    return render_template('adminhome.html')


@admin.route('/adminmanagesmaster',methods=['get','post'])
def adminmanagesmaster():
    data={}

    if 'add' in request.form:
        fname=request.form['fname']
        lname=request.form['lname']
        place=request.form['place']
        num=request.form['num']
        email=request.form['email']
        uname=request.form['uname']
        pasw=request.form['pasw']

        q="insert into login values(null,'%s','%s','stationmaster')"%(uname,pasw)
        lid=insert(q)
        q="insert into stationmaster values(null,'%s','%s','%s','%s','%s','%s') "%(lid,fname,lname,place,num,email)
        insert(q)
        return redirect(url_for("admin.adminmanagesmaster"))

    q="select * from stationmaster"
    data['res']=select(q)

    if 'action' in request.args:
        action=request.args['action']
        smid=request.args['smid']
        logid=request.args['logid']
    
    else:
        action=None

    if action == "update":
        q="select * from stationmaster where smaster_id='%s'"%(smid)
        data['changeval']=select(q)

        if 'update' in request.form:
            fname=request.form['fname']
            lname=request.form['lname']
            place=request.form['place']
            num=request.form['num']
            email=request.form['email']
          

            q="update stationmaster set fname='%s', lname='%s', place='%s', phone='%s', email='%s' where smaster_id='%s' "%(fname,lname,place,num,email,smid)
            update(q)
            return redirect(url_for("admin.adminmanagesmaster"))

    if action=='delete':
        q="delete from stationmaster where smaster_id='%s'"%(smid)
        delete(q)
        q="delete from login where login_id='%s'"%(logid)
        delete(q)
        return redirect(url_for("admin.adminmanagesmaster"))
    return render_template('adminmanagesmaster.html',data=data)




@admin.route('/adminmanagefees',methods=['get','post'])
def adminmanagefees():
    data={}

    if 'add' in request.form:
        weight=request.form['weight']
        fees=request.form['fees']
        
        q="insert into fees values(null,'%s','%s')"%(fees,weight)
        insert(q)
        return redirect(url_for("admin.adminmanagefees"))

    q="select * from fees"
    data['res']=select(q)

    if 'action' in request.args:
        action=request.args['action']
        feeid=request.args['feeid']
    else:
        action=None

    if action == "update":
        q="select * from fees where fees_id='%s'"%(feeid)
        data['changefees']=select(q)

        if 'update' in request.form:
            fees=request.form['fees']
            weight=request.form['weight']
          
          

            q="update fees set weight='%s', fees='%s' where fees_id='%s' "%(weight,fees,feeid)
            update(q)
            return redirect(url_for("admin.adminmanagefees"))

    if action=='delete':
        q="delete from fees where fees_id='%s'"%(feeid)
        delete(q)
        return redirect(url_for("admin.adminmanagefees"))
    return render_template('adminmanagefees.html',data=data)


@admin.route("/adminviewpostman")
def adminviewpostman():
    data={}
    q="select * from postman"
    data['res']=select(q)
    return render_template("adminviewpostman.html",data=data)


@admin.route("/adminviewusers")
def adminviewusers():
    data={}
    q="select * from user"
    data['res']=select(q)
    return render_template("adminviewusers.html",data=data)


@admin.route("/adminviewletterdetails")
def adminviewletterdetails():
    data={}
    q="select * from letter"
    data['res']=select(q)
    return render_template("adminviewletterdetails.html",data=data)


@admin.route("/adminviewcomplaints",methods=['get','post'])
def adminviewcomplaints():
    data={}
    q="select * from user inner join complaint using (user_id)"
    data['res']=select(q)

    if 'action' in request.args:
        action=request.args['action']
        cid=request.args['cid']
    else:
        action=None

    if action == "reply":
        data['replysec']=True

        if 'submit' in request.form:
            reply=request.form['reply']

            q="update complaint set reply='%s' where complaint_id='%s'"%(reply,cid)
            update(q)
            return redirect(url_for("admin.adminviewcomplaints"))
    return render_template("adminviewcomplaints.html",data=data)