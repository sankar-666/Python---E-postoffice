from flask import *
from database import *


api=Blueprint('api',__name__)

@api.route('/login')
def login():
    data={}
    un=request.args['username']
    pwd=request.args['password']
    print(un,pwd)
    z="select * from `login` where username='%s' and password='%s' "%(un,pwd)
    res=select(z)

    if res:
        data['status']='success'
        data['data']=res
    else:
        data['status']='failed'
    return str(data)

@api.route("/userreg",methods=['get','post'])
def userreg():
    data={}

    fname=request.args['fname']
    lname=request.args['lname']
 
    place=request.args['place']


    phone=request.args['phone']
    email=request.args['email']
    username=request.args['uname']
    password=request.args['pass']

    q="insert into `login` values(NULL,'%s','%s','user') "%(username,password)
    ref=insert(q)
    v="insert into `user` values(NULL,'%s','%s','%s','%s','%s','%s') "%(ref,fname,lname,place,phone,email)
    insert(v)
    data['status']='success'
    return str(data)


@api.route('/viewletters')
def viewletters():
    data={}
    search=request.args['search']
    lid=request.args['lid']
    z="select * from letter inner join stationmaster using (smaster_id) where t_num like '%s' "%(search)
 
    res=select(z)

    if res:
        data['status']='success'
        data['data']=res
    else:
        data['status']='failed'
    data['method']="viewletters"
    return str(data)

@api.route('/postmanviewletters')
def postmanviewletters():
    data={}
   
    lid=request.args['lid']
    z="select * from letter inner join stationmaster using (smaster_id) inner join track using (letter_id) where status <> 'delevered sucessfully'"
 
    res=select(z)

    if res:
        data['status']='success'
        data['data']=res
    else:
        data['status']='failed'
    data['method']="postmanviewletters"
    return str(data)

@api.route('/postmanupdateletter')
def postmanupdateletter():
    data={}
   
    lid=request.args['lid']
    letterid=request.args['letterid']
    trid=request.args['trid']
    q="update track set smaster_id=(select postman_id from postman where login_id='%s'), status='delevered sucessfully', place=(select place from postman where login_id='%s') where track_id='%s'"%(lid,lid,trid)
    print(q)
    update(q)


    data['status']='success'
    data['method']="postmanupdateletter"
    return str(data)


@api.route('/viewstationmasters')
def viewstationmasters():
    data={}
    z="select * from stationmaster "
    res=select(z)

    if res:
        data['status']='success'
        data['data']=res
    else:
        data['status']='failed'
    data['method']="viewstationmasters"
    return str(data)




@api.route('/userreqfd')
def userreqfd():
    data={}
    lid=request.args['lid']
    amount=request.args['amount']
    sid=request.args['sid']
    z="insert into fixeddeposit values(null,(select user_id from user where login_id='%s'),'%s','%s',curdate(),'pending')"%(lid,sid,amount)
    res=insert(z)

    if res:
        data['status']='success'
        data['data']=res
    else:
        data['status']='failed'
    
    return str(data)

@api.route('/userreqaccount')
def userreqaccount():
    data={}
    lid=request.args['lid']

    sid=request.args['sid']
    z="insert into account values(null,(select user_id from user where login_id='%s'),'%s','0','0','pending')"%(lid,sid)
    res=insert(z)

    if res:
        data['status']='success'
        data['data']=res
    else:
        data['status']='failed'
    
    return str(data)


@api.route('/userviewprofile')
def userviewprofile():
    data={}
    lid=request.args['lid']
    z="select * from user inner join login using (login_id) where user_id=(select user_id from user where login_id='%s')"%(lid)
    res=select(z)

    if res:
        data['status']='success'
        data['data']=res
    else:
        data['status']='failed'
    data['method']="userviewprofile"
    return str(data)


@api.route('/userupdateprofile')
def userupdateprofile():
    data={}
    lid=request.args['lid']
    fname=request.args['fname']
    lname=request.args['lname']
 
    place=request.args['place']


    phone=request.args['phone']
    email=request.args['email']
    username=request.args['uname']

    z="update user set fname='%s', lname='%s', place='%s', phone='%s', email='%s' where login_id='%s'"%(fname,lname,place,phone,email,lid)
    update(z)
    q="update login set username='%s' where login_id='%s'"%(username,lid)
    update(q)
  
    data['status']='success'
  
    
   
    data['method']="userupdateprofile"
    return str(data)

@api.route('/viewavailableloans')
def viewavailableloans():
    data={}
    z="select * from loan "
    res=select(z)

    if res:
        data['status']='success'
        data['data']=res
    else:
        data['status']='failed'
    data['method']="viewavailableloans"
    return str(data)




@api.route('/reqforloan')
def reqforloan():
    data={}
    lid=request.args['lid']
    loanid=request.args['loanid']
    amount=request.args['amount']
    q="select * from loan where loan_id in (select loan_id from loanrequest where loan_id='%s' and user_id =(select user_id from user where login_id='%s'))"%(loanid,lid)
    res=select(q)
    if res:
        data['status']='already'
    else:
        z="insert into loanrequest values(null,(select user_id from user where login_id='%s'),'%s','%s','pending')"%(lid,loanid,amount)

        insert(z)

        data['status']='success'
    data['method']="reqforloan"
    

    

    return str(data)

@api.route('/viewmyfd')
def viewmyfd():
    data={}
    lid=request.args['lid']
    z="select * from fixeddeposit where user_id= (select user_id from user where login_id='%s')"%(lid)
    res=select(z)

    if res:
        data['status']='success'
        data['data']=res
    else:
        data['status']='failed'
    data['method']="viewmyfd"
    return str(data)


@api.route('/viewmyloan')
def viewmyloan():
    data={}
    lid=request.args['lid']
    z="select * from loan inner join loanrequest using (loan_id) where user_id= (select user_id from user where login_id='%s')"%(lid)
    res=select(z)

    if res:
        data['status']='success'
        data['data']=res
    else:
        data['status']='failed'
    data['method']="viewmyloan"
    return str(data)

@api.route('/viewmyaccountlist')
def viewmyaccountlist():
    data={}
    lid=request.args['lid']
    z="select * from account where status='approved' and  user_id= (select user_id from user where login_id='%s')"%(lid)
    res=select(z)

    if res:
        data['status']='success'
        data['data']=res
    else:
        data['status']='failed'
    data['method']="viewmyaccountlist"
    return str(data)


@api.route('/accountbalance')
def accountbalance():
    data={}
    lid=request.args['log_id']
    amount=request.args['amount']
   

    z="update account set balance=balance+'%s' where user_id=(select user_id from user where login_id='%s')"%(amount,lid)
    update(z)

  
    data['status']='success'
  
    
   
   
    return str(data)



@api.route('/transfermoney')
def transfermoney():
    data={}
    lid=request.args['lid']
    acno='%'+request.args['acno']+'%'
    acc=request.args['acno']
    amount=request.args['amount']
    myac=request.args['myac']
   
    q="select * from account where account like '%s'"%(acno)
    res=select(q)
    if res:
        q="update account set balance=balance+'%s' where account='%s'"%(amount,acc)
        update(q)
        q="update account set balance=balance-'%s' where user_id=(select user_id from user where login_id='%s')"%(amount,lid)
        update(q)
        q="insert into monthlytransfer values(null,'%s','%s','%s',curdate())"%(myac,acc,amount)
        insert(q)
        data['status']='success'
    else:
        data['status']='notfound'
        
    return str(data)

    
from date import *
@api.route("/makepayment")
def makepayment():
    loanid=request.args['loanid']
    amount=request.args['amount']
    data={}

    a=getdate()
    month=str(a['month'])
    year=str(a['year'])

    q="select date from payment where loan_id='%s' order by payment_id desc limit 1"%(loanid)
    print(q)
    val=select(q)
    if val:
        tabledate=val[0]['date']
        tblyear=tabledate[0:4]
        tblmonth=tabledate[5:7]

        if tblmonth==month and tblyear==year:
            data['status']="samemonth"
        else:
            q="insert into payment values (null,'%s','%s',curdate(),'pending')"%(loanid,amount)
            insert(q)
            data['status']="success"
    else:
        q="insert into payment values (null,'%s','%s',curdate(),'pending')"%(loanid,amount)
        insert(q)
        data['status']="success"

    return str(data)


@api.route("/addcomplaint")
def addcomplaint():
    complaint=request.args['complaint']
    lid=request.args['lid']
   
    data={}

    q="insert into complaint values (null,(select user_id from user where login_id='%s'),'%s','pending',curdate())"%(lid,complaint)
    insert(q)
    data['status']="success"
    data['method']="addcomplaint"
    return str(data)
  
    
@api.route('/viewcomplaint')
def viewcomplaint():
    data={}
    lid=request.args['lid']
    z="select * from complaint where user_id= (select user_id from user where login_id='%s')"%(lid)
    res=select(z)

    if res:
        data['status']='success'
        data['data']=res
    else:
        data['status']='failed'
    data['method']="viewcomplaint"
    return str(data)

    
   
   